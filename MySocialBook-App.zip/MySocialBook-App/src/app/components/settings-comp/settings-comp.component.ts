import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settings-comp',
  templateUrl: './settings-comp.component.html',
  styleUrls: ['./settings-comp.component.css']
})
export class SettingsCompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
