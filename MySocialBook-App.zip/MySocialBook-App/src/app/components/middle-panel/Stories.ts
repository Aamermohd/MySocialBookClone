import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'appss',
  template:""
})
export class MiddlePanelComponent implements OnInit {
  images:any[]=[{'src':"https://i.postimg.cc/TPh453Zz/upload.png"},
  {'src':"https://i.postimg.cc/XNPtfdVs/member-1.png"},
  {'src':"https://i.postimg.cc/4NhqByys/member-2.png"},
  {'src':"https://i.postimg.cc/FH5qqvkc/member-3.png"},
  {'src':"https://i.postimg.cc/Sx65bPcP/member-4.png"}]

  constructor() { }

  ngOnInit() {
  }
}