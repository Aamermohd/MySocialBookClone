import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-middle-panel',
  templateUrl: './middle-panel.component.html',
  styleUrls: ['./middle-panel.component.css']
})
export class MiddlePanelComponent implements OnInit {
  title:string="Mystory"
  images:any[]=[{'src':"https://i.postimg.cc/TPh453Zz/upload.png"},
  {'src':"https://i.postimg.cc/XNPtfdVs/member-1.png"},
  {'src':"https://i.postimg.cc/4NhqByys/member-2.png"},
  {'src':"https://i.postimg.cc/FH5qqvkc/member-3.png"},
  {'src':"https://i.postimg.cc/Sx65bPcP/member-4.png"}]

  constructor() { }

  ngOnInit() {
    
  let Arr=document.getElementById("story1")
  Arr?.setAttribute('src',"https://i.postimg.cc/TPh453Zz/upload.png");
  let Arr1=document.getElementById("Story2")
  Arr1?.setAttribute('src',"https://i.postimg.cc/XNPtfdVs/member-1.png");
  let Arr2=document.getElementById("story3")
  Arr2?.setAttribute('src',"https://i.postimg.cc/4NhqByys/member-2.png");
  let Arr3=document.getElementById("story4")
  Arr3?.setAttribute('src',"https://i.postimg.cc/FH5qqvkc/member-3.png");
  let Arr4=document.getElementById("story5")
  Arr4?.setAttribute('src',"https://i.postimg.cc/Sx65bPcP/member-4.png");
  }
}
