import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advertisements',
  templateUrl: './advertisements.component.html',
  styleUrls: ['./advertisements.component.css']
})
export class AdvertisementsComponent implements OnInit {

  ad_image = "https://4.bp.blogspot.com/-CZvrYPzd8eI/Uw9fnDSGxBI/AAAAAAAAHpg/px2SvBdwtCQ/s1600/Vicco+Vajradanti+Ayurvedic+Vegan+Toothpaste+review.jpg";

  constructor() { }

  ngOnInit(): void {
  }

}
