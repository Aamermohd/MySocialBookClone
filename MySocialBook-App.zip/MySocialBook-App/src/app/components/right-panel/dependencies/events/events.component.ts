import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {

  eventsArray = [{
    date: 14,
    month: "March",
    event_name: "ADO DotNet",
    event_location: "WaveRock SEZ 2.3"
  }, {
    date: 15,
    month: "March",
    event_name: "Angular Hands On",
    event_location: "WaveRock SEZ 2.1"
  }, {
    date: 25,
    month: "December",
    event_name: "XMas Celebrations",
    event_location: "Vatican City"
  }]

  constructor() { 
    console.log(this.eventsArray);
  }

  ngOnInit(): void {
  }

}
