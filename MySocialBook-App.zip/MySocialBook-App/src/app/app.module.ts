import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { LeftPanelComponent } from './components/left-panel/left-panel.component';
import { MiddlePanelComponent } from './components/middle-panel/middle-panel.component';
import { RightPanelComponent } from './components/right-panel/right-panel.component';
import { SettingsCompComponent } from './components/settings-comp/settings-comp.component';
import { EventsComponent } from './components/right-panel/Dependencies/Events/events.component'; 
import { AdvertisementsComponent } from './components/right-panel/Dependencies/Advertisements/advertisements.component';
import { ConversationsComponent } from './components/right-panel/Dependencies/Conversations/conversations.component';
import { FooterComponent } from './components/footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LeftPanelComponent,
    MiddlePanelComponent,
    RightPanelComponent,
    SettingsCompComponent,
    EventsComponent,
    AdvertisementsComponent,
    ConversationsComponent,
    FooterComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
